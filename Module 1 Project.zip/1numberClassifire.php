<?php



# method 2

// This echo will show in Front
echo "Enter a number: ";
// (int) means integer
$number = (int) readline();
// Conditional statements

if ($number === 999) {  //Please check if the number is 999
    echo "You Are A Pure Panda.\n"; 
} elseif ($number > 0 && $number <= 200) { 
    echo "You Are Regular Panda.\n";
} elseif ($number > 200) { 
    echo "You Have Submitted The Wrong Credential Panda.\n";
} elseif ($number < 0) {  // Please Check if the number is negative
    echo "You Are A Nagetive Panda.\n";
} else {  
    echo "You Are Not A Panda, You Are A Valluk.\n"; 
}
// Let's Proceed!






# mathod 1

/*
//this echo will show in Front
 echo "Enter a number: ";
 //(int) means integer
 $number = (int) readline();
 //conditiontal statements
 if ($number > 0) {
 echo "This is your account Panda.\n";
 } elseif ($number < 0) {
 echo "You put wrong credentials Panda .\n";
 } else { 
 echo "You are not a Panda You are a Valluk.\n";
 }
//Let's Proceed!
*/ 




